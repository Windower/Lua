# Gallionaire Version 1.3

-- Tracks Total Gallimaufry, Record galli gained in a run, and galli earned in current run.
-- Plays sounds at gallimaufry thresholds and  if you deal 99,999 dmg.

## Known Issues

No known issues :)

This addon is still being updated and kept up, feature updates planned.

## Installation
After downloading, extract to your Windower addons folder. Make sure the folder is called Gallionaire.  Your file structure should look like this:

    Windower4/addons/Gallionaire/Gallionaire.lua

Once the addon is in your Windower addons folder...

    lua load Gallionaire

## Commands

-- //ga setgoal (number)  ( sets your  /#### gallimaufry goal. )

-- //ga togglesound / ts  ( toggles sound effects on and off. (On by default: The setting will save to settings file and remain until changed back.) )

-- //ga reset  ( resets your earned gallimaufry )

-- //ga reload or //ga r  ( reloads the addon )

-- //ga save ( manually saves, and if your earned > record, overwrites record.

-- //ga show ( makes the display visible.

-- //ga hide ( hides the display.

-- //ga help (displays this list of commands in the log ingame.

